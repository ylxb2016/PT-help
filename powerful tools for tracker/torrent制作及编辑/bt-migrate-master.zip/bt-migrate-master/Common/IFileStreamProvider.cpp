#include "IFileStreamProvider.h"

IFileStreamProvider::~IFileStreamProvider() noexcept(false)
{
}
