#include "ITorrentStateStore.h"

ITorrentStateStore::~ITorrentStateStore() = default;

ImportCancelledException::~ImportCancelledException() = default;
