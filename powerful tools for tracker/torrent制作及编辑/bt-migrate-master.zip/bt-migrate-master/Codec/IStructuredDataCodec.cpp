#include "IStructuredDataCodec.h"

IStructuredDataCodec::~IStructuredDataCodec() = default;
