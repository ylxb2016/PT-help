tempita package
===============

.. automodule:: tempita
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

tempita.compat3 module
----------------------

.. automodule:: tempita.compat3
    :members:
    :undoc-members:
    :show-inheritance:


