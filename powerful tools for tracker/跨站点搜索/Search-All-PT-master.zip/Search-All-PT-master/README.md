<h1>PT一键搜索/登录Javascript脚本</h1>
没太大的技术含量，旨在方便广大PTer，免费使用，随便传播但请保留出处：
<ul>
	<li><h2>一键搜索所有已加入的PT站点</h2></li>
	<li><h2>只需一个标签页就可显示所有已加入的PT站点</h2></li>
</ul>
注意：
<ul>
	<li><h2>使用时请允许站点及浏览器的cookie</h2></li>
	<li><h2>推荐使用chrome浏览</h2></li>
	<li><h2>只添加了我已有账号的PT站点</h2></li>
</ul>
求其它PT邀，后根据搜索结果页面url加入一键搜索功能。imxray#一六三.com，改成163<br><br>
如果你觉得此工具有用，请捐赠我:<br>
<img src="https://raw.githubusercontent.com/Dreamray/Search-All-PT/master/donate/donate.jpg" alt="">
