-------------
srrGUI v1.2.1
-------------

ABOUT: A simple GUI wrapper for the pyReScene w32 CLI binaries.

USAGE: Select process, select paths, run process! Read tooltips for extra info.

DEPENDENCIES: srrGUI.exe must be in the same directory as the pyReScene CLI binaries (pyrescene.exe, retag.exe, srr.exe, srs.exe). If the pyReScene directory is added To the PATH environment variable then srrGUI can be executed from any location.

KEYBOARD SHORTCUTS: Alt+1-4 = select process; Tab = cycle forwards through controls; Shift+Tab = cycle backwards through controls; Space = press button/toggle checkbox.

SYSTEM REQUIREMENTS: Windows XP or higher.

VERSION HISTORY: See Changelog.txt for more details.
